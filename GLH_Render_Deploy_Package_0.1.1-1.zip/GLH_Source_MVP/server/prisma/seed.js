import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();

async function main() {
  const adminPass = process.env.SEED_ADMIN_PASSWORD;
  if (adminPass) {
    if (adminPass.length < 12) throw new Error('SEED_ADMIN_PASSWORD must be at least 12 characters');
    const passwordHash = await bcrypt.hash(adminPass, 12);
    await prisma.user.upsert({
      where: { username: 'admin' },
      update: { passwordHash, role: 'ADMIN', active: true },
      create: { username: 'admin', email: 'admin@glh.local', fullName: 'GLH Administrator', passwordHash, role: 'ADMIN' }
    });
    console.log('Admin account created/updated from SEED_ADMIN_PASSWORD.');
  } else if (process.env.NODE_ENV === 'production') {
    console.log('SEED_ADMIN_PASSWORD not set; admin seed skipped.');
  }

  if (process.env.SEED_DEMO_DATA === 'true') {
    await prisma.user.upsert({
      where: { username: 'clientdemo' }, update: {},
      create: { username: 'clientdemo', email: 'client@glh.local', fullName: 'Demo Client', passwordHash: await bcrypt.hash('ClientDemo123!', 12), role: 'CLIENT', country: 'Yemen', city: 'Sanaa' }
    });
    if ((await prisma.financeProduct.count()) === 0) await prisma.financeProduct.create({ data: { name: 'تمويل المشتريات التجارية', category: 'TRADE_FINANCE', description: 'منتج تجريبي قابل للتعديل وفق سياسة الجهة الممولة', minAmount: 100, maxAmount: 50000, currency: 'USD', termMonths: 6, profitRate: 8.5 } });
    if ((await prisma.product.count()) === 0) await prisma.product.create({ data: { name: 'عينة منتج تجاري', description: 'بيانات توضيحية تجريبية', category: 'عام', price: 25, currency: 'USD', stock: 100, published: true } });
    console.log('Demo data seeded.');
  }
}
main().catch(error => { console.error(error); process.exit(1); }).finally(() => prisma.$disconnect());
