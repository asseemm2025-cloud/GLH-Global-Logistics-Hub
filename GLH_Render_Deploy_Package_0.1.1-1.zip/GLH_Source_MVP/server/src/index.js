import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';
import path from 'path';
import { fileURLToPath } from 'url';
import auth from './routes/auth.js';
import catalog from './routes/catalog.js';
import orders from './routes/orders.js';
import finance from './routes/finance.js';
import swift from './routes/swift.js';

if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL is required');
if (!process.env.JWT_SECRET || process.env.JWT_SECRET.length < 32) throw new Error('JWT_SECRET must contain at least 32 characters');

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
app.set('trust proxy', 1);
app.use(helmet({ contentSecurityPolicy: false }));
const allowedOrigins = process.env.WEB_ORIGIN?.split(',').map(x => x.trim()).filter(Boolean);
app.use(cors(allowedOrigins?.length ? { origin: allowedOrigins } : { origin: true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('combined'));
app.use('/api/auth', rateLimit({ windowMs: 15 * 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }), auth);
app.use('/api/catalog', catalog);
app.use('/api/orders', orders);
app.use('/api/finance', finance);
app.use('/api/swift', swift);
app.get('/api/health', (_req, res) => res.json({ status: 'ok', service: 'GLH API', version: '0.1.1' }));
app.use(express.static(path.resolve(__dirname, '../../web')));
app.use((err, _req, res, _next) => {
  console.error(err);
  res.status(500).json({ error: 'حدث خطأ داخلي' });
});
const port = Number(process.env.PORT || 4000);
app.listen(port, '0.0.0.0', () => console.log(`GLH API listening on ${port}`));
