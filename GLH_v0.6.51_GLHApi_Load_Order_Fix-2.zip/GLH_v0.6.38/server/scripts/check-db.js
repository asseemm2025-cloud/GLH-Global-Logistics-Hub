import 'dotenv/config';
import { PrismaClient } from '@prisma/client';
const prisma = new PrismaClient();
try {
  if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL غير مضبوط');
  await prisma.$connect();
  await prisma.$queryRaw`SELECT 1`;
  const tables = await prisma.$queryRaw`SELECT COUNT(*)::int AS count FROM information_schema.tables WHERE table_schema = 'public'`;
  console.log(JSON.stringify({status:'connected',database:'PostgreSQL',publicTables:tables[0]?.count ?? 0},null,2));
  if ((tables[0]?.count ?? 0) < 5) process.exitCode = 2;
} catch (error) {
  console.error(JSON.stringify({status:'failed',message:error.message},null,2));
  process.exitCode = 1;
} finally { await prisma.$disconnect(); }
