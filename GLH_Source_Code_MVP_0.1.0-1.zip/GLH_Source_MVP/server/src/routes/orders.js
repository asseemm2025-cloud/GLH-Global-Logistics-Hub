import { Router } from 'express';
import { z } from 'zod';
import { prisma } from '../db.js';
import { requireAuth, allowRoles } from '../middleware/auth.js';
const router=Router();
const itemSchema=z.object({name:z.string().min(1),supplier:z.string().optional(),unitPrice:z.number().nonnegative(),quantity:z.number().positive(),unit:z.string().optional()});
router.post('/',requireAuth,async(req,res)=>{
 const schema=z.object({type:z.enum(['LOCAL','INTERNATIONAL']),originCountry:z.string().min(2),originCity:z.string().optional(),destinationCountry:z.string().min(2),destinationCity:z.string().optional(),items:z.array(itemSchema).min(1),shippingMethod:z.string().optional(),shippingCompany:z.string().optional(),shippingCost:z.number().nonnegative().optional(),currency:z.string().default('USD'),paymentMethod:z.string().optional(),transferType:z.string().optional(),insuranceNeeded:z.boolean().default(false),insuranceCompany:z.string().optional(),insuredValue:z.number().nonnegative().optional(),insuranceCost:z.number().nonnegative().optional(),notes:z.string().optional(),financeProductId:z.string().optional(),requestedAmount:z.number().positive().optional(),termMonths:z.number().int().positive().optional(),financePurpose:z.string().optional()});
 const p=schema.safeParse(req.body);if(!p.success)return res.status(400).json({error:'تحقق من بيانات الطلب',details:p.error.flatten()});
 if(p.data.type==='INTERNATIONAL'&&!p.data.transferType&&!p.data.paymentMethod)return res.status(400).json({error:'حدد وسيلة الدفع أو نوع التحويل للطلب الدولي'});
 if(p.data.paymentMethod==='FINANCING'){
   if(!p.data.financeProductId||!p.data.requestedAmount||!p.data.termMonths||!p.data.financePurpose)return res.status(400).json({error:'أكمل منتج التمويل والمبلغ والمدة والغرض'});
   const fp=await prisma.financeProduct.findUnique({where:{id:p.data.financeProductId}});
   if(!fp||!fp.enabled)return res.status(400).json({error:'منتج التمويل غير متاح'});
   if(p.data.requestedAmount<Number(fp.minAmount)||p.data.requestedAmount>Number(fp.maxAmount))return res.status(400).json({error:'المبلغ خارج حدود منتج التمويل'});
 }
 const {financeProductId,requestedAmount,termMonths,financePurpose,...orderFields}=p.data;
 const result=await prisma.$transaction(async(tx)=>{
   const order=await tx.order.create({data:{...orderFields,customerId:req.user.id,orderNo:`GLH-${Date.now()}`}});
   let financeApplication=null;
   if(order.paymentMethod==='FINANCING') financeApplication=await tx.financeApplication.create({data:{applicationNo:`FIN-${Date.now()}`,userId:req.user.id,orderId:order.id,financeProductId,requestedAmount,currency:order.currency,termMonths,purpose:financePurpose}});
   await tx.auditLog.create({data:{userId:req.user.id,action:'CREATE',entity:'Order',entityId:order.id}});
   return {order,financeApplication};
 });
 res.status(201).json(result);
});
router.get('/mine',requireAuth,async(req,res)=>res.json(await prisma.order.findMany({where:{customerId:req.user.id},include:{attachments:true,financeApps:true},orderBy:{createdAt:'desc'}})));
router.get('/',requireAuth,allowRoles('ADMIN','OPS','FINANCE'),async(req,res)=>res.json(await prisma.order.findMany({include:{customer:{select:{fullName:true,username:true,phone:true,country:true}},attachments:true},orderBy:{createdAt:'desc'}})));
router.patch('/:id/status',requireAuth,allowRoles('ADMIN','OPS'),async(req,res)=>{
 const status=z.enum(['SUBMITTED','UNDER_REVIEW','QUOTED','APPROVED','IN_PROGRESS','SHIPPED','DELIVERED','REJECTED','CANCELLED']).safeParse(req.body.status);
 if(!status.success)return res.status(400).json({error:'حالة غير معتمدة'});
 const order=await prisma.order.update({where:{id:req.params.id},data:{status:status.data}});
 await prisma.auditLog.create({data:{userId:req.user.id,action:'UPDATE_STATUS',entity:'Order',entityId:order.id,details:{status:status.data}}});res.json(order);
});
export default router;
