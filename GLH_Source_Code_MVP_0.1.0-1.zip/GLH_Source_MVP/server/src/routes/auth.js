import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { z } from 'zod';
import { prisma } from '../db.js';
const router = Router();

router.post('/register', async (req, res) => {
  const parsed = z.object({ username:z.string().min(4).max(40), password:z.string().min(10), fullName:z.string().min(2), phone:z.string().optional(), email:z.string().email().optional(), country:z.string().optional(), city:z.string().optional() }).safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error:'تحقق من البيانات؛ اسم المستخدم 4 أحرف وكلمة المرور 10 أحرف على الأقل', details:parsed.error.flatten() });
  const data = parsed.data;
  try {
    const user = await prisma.user.create({ data:{ ...data, passwordHash:await bcrypt.hash(data.password, 12), role:'CLIENT' }, select:{id:true,username:true,fullName:true,role:true} });
    res.status(201).json({ user });
  } catch { res.status(409).json({ error:'اسم المستخدم أو البريد مستخدم مسبقاً' }); }
});

router.post('/login', async (req,res) => {
  const { username, password } = req.body || {};
  if (!username || !password) return res.status(400).json({error:'أدخل اسم المستخدم وكلمة المرور'});
  const user = await prisma.user.findUnique({ where:{username} });
  if (!user || !user.active || !(await bcrypt.compare(password,user.passwordHash))) return res.status(401).json({error:'بيانات الدخول غير صحيحة'});
  const token = jwt.sign({sub:user.id,role:user.role},process.env.JWT_SECRET,{expiresIn:process.env.JWT_EXPIRES_IN || '8h'});
  res.json({ token, user:{id:user.id,username:user.username,fullName:user.fullName,role:user.role} });
});
export default router;
