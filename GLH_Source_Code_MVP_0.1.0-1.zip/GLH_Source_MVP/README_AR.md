# منصة GLH — المصدر البرمجي التأسيسي (MVP 0.1.0)

هذا المستودع هو بداية تنفيذ فعلية قابلة للتشغيل والتطوير، وليس مجرد نموذج HTML. يحتوي على واجهة ويب أولية وواجهة API وخادم وقاعدة PostgreSQL ومخطط بيانات.

## المكونات
- `web/`: واجهة العميل والإدارة (HTML/CSS/JavaScript) وتستهلك API مركزياً، ومهيأة كتطبيق ويب قابل للتثبيت PWA.
- `server/`: خادم Node.js + Express، المصادقة، صلاحيات الأدوار، الطلبات، المنتجات، التمويل، وسجلات SWIFT.
- `server/prisma/schema.prisma`: مخطط قاعدة البيانات.
- `docker-compose.yml`: تشغيل PostgreSQL محلياً.

## المتطلبات
- Node.js 20 أو أحدث.
- Docker Desktop أو PostgreSQL 16.

## التشغيل على جهاز المطور
1. انسخ `.env.example` إلى `.env` في جذر المشروع لتشغيل PostgreSQL عبر Docker.
2. انسخ `server/.env.example` إلى `server/.env`، ثم غيّر `JWT_SECRET` و`POSTGRES_PASSWORD` إلى قيم قوية وفريدة.
3. شغّل قاعدة البيانات: `docker compose up -d db`
4. ثبّت الحزم داخل مجلد `server`: `cd server && npm install`
5. أنشئ Prisma Client: من الجذر `npm run db:generate`
6. نفّذ الترحيل: `npm run db:migrate`
7. أضف البيانات التجريبية: `npm run db:seed`
8. شغّل الخادم: من مجلد `server` نفّذ `npm run dev`
9. افتح `http://localhost:4000`.

> الواجهة تُقدّم من الخادم على المنفذ 4000. ويمكن تشغيلها على Vite مستقبلاً؛ النسخة الحالية لا تحتاج build للواجهة.

## حسابات التطوير بعد seed
- مدير النظام: `admin` / `ChangeMe123!`
- عميل تجريبي: `clientdemo` / `ClientDemo123!`

غيّر كلمات المرور فوراً، ولا تستخدم هذه الحسابات في بيئة عامة.

## الوظائف المنفذة في هذه الدفعة
- تسجيل حساب عميل وتسجيل الدخول باستخدام JWT وتخزين كلمات المرور باستخدام bcrypt.
- تصفح المنتجات المنشورة دون تسجيل دخول.
- إنشاء طلب محلي أو دولي بعد تسجيل الدخول مع المنتجات، المورد، الشحن، التأمين، طريقة الدفع ونوع التحويل. اختيار التمويل ينشئ طلب تمويل مرتبطاً بالطلب ضمن معاملة قاعدة بيانات واحدة.
- عرض طلبات العميل.
- إدارة الطلبات وتحديث حالاتها من لوحة الإدارة.
- إضافة المنتجات من لوحة الإدارة ونشرها في واجهة العميل.
- منتجات التمويل وعرضها API، وإنشاء طلبات التمويل ومراجعتها عبر API.
- سجل عمليات SWIFT داخلي لأغراض المتابعة والتدقيق فقط.
- سجل تدقيق أولي للإنشاء وتغيير حالة الطلب.
- صلاحيات خادمية للأدوار ADMIN وOPS وFINANCE وCLIENT.

## حدود هذه النسخة
- هذه دفعة تأسيسية وليست منصة إنتاج مكتملة. وحدات كثيرة من النطاق المعتمد تحتاج إلى استكمال تدريجي: المتاجر متعددة البائعين، إدارة الموردين والشركات، RFQ والعروض، الخرائط والتتبع، رفع المرفقات الآمن، إدارة بوليصات التأمين، التسويات والمدفوعات، Swift connectivity، الاعتمادات المستندية، التقارير، إدارة الصلاحيات التفصيلية، تطبيق Android/iOS.
- لا ترسل هذه النسخة رسائل SWIFT ولا تنفذ تحويلات أو اعتمادات مستندية أو مدفوعات فعلية ولا تصرف تمويلاً.
- لم تُنفذ مراجعة أمنية أو اختبار اختراق أو UAT إنتاجي.
- لا تضع مفاتيح أو كلمات مرور حقيقية في المستودع. استخدم مدير أسرار عند النشر.

## API الأساسية
- `POST /api/auth/register`
- `POST /api/auth/login`
- `GET /api/catalog/products`
- `GET /api/catalog/finance-products`
- `POST /api/catalog/products` (ADMIN/OPS)
- `POST /api/orders` (authenticated)
- `GET /api/orders/mine` (authenticated)
- `GET /api/orders` (ADMIN/OPS/FINANCE)
- `PATCH /api/orders/:id/status` (ADMIN/OPS)
- `POST /api/finance/applications` (authenticated)
- `GET /api/finance/applications/mine` (authenticated)
- `GET /api/finance/applications` (ADMIN/FINANCE)
- `PATCH /api/finance/applications/:id/status` (ADMIN/FINANCE)
- `GET /api/swift` (ADMIN/OPS/FINANCE)
- `POST /api/swift` (ADMIN/FINANCE)
- `GET /api/health`

## قبل الإطلاق
يلزم مراجعة المتطلبات القانونية والامتثال والخصوصية في الدول المستهدفة، اختبار النسخ الاحتياطي والتعافي، HTTPS، إدارة الأسرار، سياسات كلمات المرور والجلسات، مراقبة السجلات، اختبار الصلاحيات، وتدقيق مستقل للتكاملات المالية والمصرفية.
