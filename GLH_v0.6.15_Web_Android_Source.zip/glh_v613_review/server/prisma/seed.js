import 'dotenv/config';
import bcrypt from 'bcryptjs';
import { PrismaClient } from '@prisma/client';
import { PERMISSIONS, DEFAULT_GRANTS } from '../src/security/permission-catalog.js';
const prisma = new PrismaClient();

async function main() {
  const adminPass = process.env.SEED_ADMIN_PASSWORD;
  if (adminPass) {
    if (adminPass.length < 12) throw new Error('SEED_ADMIN_PASSWORD must be at least 12 characters');
    const passwordHash = await bcrypt.hash(adminPass, 12);
    await prisma.user.upsert({
      where: { username: 'admin' },
      update: { passwordHash, role: 'ADMIN', active: true },
      create: { username: 'admin', email: 'admin@glh.local', fullName: 'GLH Administrator', passwordHash, role: 'ADMIN' }
    });
    console.log('Admin account created/updated from SEED_ADMIN_PASSWORD.');
  } else if (process.env.NODE_ENV === 'production') {
    console.log('SEED_ADMIN_PASSWORD not set; admin seed skipped.');
  }

  const sectors = [
    ['SEA','الشحن البحري','Sea Freight'],['AIR','الشحن الجوي','Air Freight'],['ROAD','الشحن البري','Road Freight'],['DOMESTIC','النقل المحلي','Domestic Transport'],['CUSTOMS','التخليص الجمركي','Customs Clearance'],['IMPORT_EXPORT','الاستيراد والتصدير','Import & Export'],['TRADE','التجارة الدولية','International Trade'],['WAREHOUSE','المخازن والتخزين','Warehousing'],['INVENTORY','إدارة المخزون','Inventory Management'],['DISTRIBUTION','التوزيع والمرحلة الأخيرة','Distribution & Last Mile'],['DELIVERY','التوصيل','Delivery'],['INSURANCE','تأمين الشحنات','Cargo Insurance'],['TRACKING','تتبع الشحنات','Shipment Tracking'],['PORTS','خدمات الموانئ','Port Services'],['AIRPORTS','خدمات المطارات','Airport Services'],['FREE_ZONES','المناطق الحرة واللوجستية','Free & Logistics Zones'],['PACKAGING','التعبئة والتغليف','Packaging'],['INSPECTION','الفحص والمعاينة','Inspection & Survey'],['CONSULTING','الاستشارات اللوجستية','Logistics Consulting'],['TRADE_FINANCE','التمويل التجاري','Trade Finance'],['ECOMMERCE','التجارة الإلكترونية','E-commerce'],['SUPPLIERS','الموردون والمصنعون','Suppliers & Manufacturers'],['AGENTS','الوكلاء ومقدمو الخدمات','Agents & Providers'],['RFQ','المناقصات وطلبات عروض الأسعار','Tenders & RFQ'],['TOOLS','الأدوات والحاسبات','Tools & Calculators'],['ACADEMY','الأكاديمية والمعرفة','Academy & Knowledge']
  ];
  for (let i=0;i<sectors.length;i++){const [code,nameAr,nameEn]=sectors[i];await prisma.sector.upsert({where:{code},update:{nameAr,nameEn,sortOrder:i,active:true},create:{code,nameAr,nameEn,sortOrder:i}})}
  const perms=PERMISSIONS.map(x=>x.key);
  for (const role of ['OPS','FINANCE','SUPPORT','COMPLIANCE','CLIENT','MERCHANT']) for (const permission of perms) {
    const allowed=(DEFAULT_GRANTS[role]||[]).includes(permission);
    await prisma.rolePermission.upsert({where:{role_permission:{role,permission}},update:{},create:{role,permission,allowed}});
  }

  const paymentMethods = [
    ['CASH','نقداً','CASH'],['BANK_TRANSFER','تحويل بنكي','BANK_TRANSFER'],['CARD','بطاقات مصرفية','CARD'],['MOBILE_WALLET','محفظة إلكترونية','MOBILE_WALLET'],['QR','الدفع عبر QR','QR'],['PAYMENT_LINK','رابط دفع','PAYMENT_LINK'],['DIRECT_DEBIT','خصم مباشر','DIRECT_DEBIT'],['CASH_ON_DELIVERY','الدفع عند الاستلام','CASH_ON_DELIVERY'],['ESCROW','حساب ضمان / وسيط','ESCROW']
  ];
  for (const [code,nameAr,type] of paymentMethods) await prisma.paymentMethod.upsert({where:{code},update:{nameAr,type},create:{code,nameAr,type,currencies:['USD','YER','SAR'],enabled:true}});

  if (process.env.SEED_DEMO_DATA === 'true') {
    await prisma.user.upsert({
      where: { username: 'clientdemo' }, update: {},
      create: { username: 'clientdemo', email: 'client@glh.local', fullName: 'Demo Client', passwordHash: await bcrypt.hash('ClientDemo123!', 12), role: 'CLIENT', country: 'Yemen', city: 'Sanaa' }
    });
    if ((await prisma.financeProduct.count()) === 0) await prisma.financeProduct.create({ data: { name: 'تمويل المشتريات التجارية', category: 'TRADE_FINANCE', description: 'منتج تجريبي قابل للتعديل وفق سياسة الجهة الممولة', minAmount: 100, maxAmount: 50000, currency: 'USD', termMonths: 6, profitRate: 8.5 } });
    if ((await prisma.product.count()) === 0) await prisma.product.create({ data: { name: 'عينة منتج تجاري', description: 'بيانات توضيحية تجريبية', category: 'عام', price: 25, currency: 'USD', stock: 100, published: true, moderationStatus:'APPROVED' } });
    console.log('Demo data seeded.');
  }
}
main().catch(error => { console.error(error); process.exit(1); }).finally(() => prisma.$disconnect());
