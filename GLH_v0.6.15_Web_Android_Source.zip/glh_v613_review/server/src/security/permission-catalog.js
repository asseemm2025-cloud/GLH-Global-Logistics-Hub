// Central permission catalogue for GLH. IDs are stable API authorization keys.
export const DEPARTMENTS = [
 {code:'EXEC',nameAr:'الإدارة العليا والحوكمة',functions:['إدارة السياسات والاستراتيجية','اعتماد الصلاحيات العليا','مراجعة الأداء والمخاطر']},
 {code:'PLATFORM',nameAr:'إدارة المنصة والتحول الرقمي',functions:['إدارة إعدادات المنصة','إدارة القطاعات والخدمات','إدارة المحتوى والهوية']},
 {code:'CUSTOMER',nameAr:'إدارة العملاء والتجار',functions:['إدارة حسابات العملاء','اعتماد التجار','مراجعة المنتجات','إدارة ربط المتاجر والبوابات']},
 {code:'LOGISTICS',nameAr:'إدارة العمليات والخدمات اللوجستية',functions:['إدارة الشحن والنقل','التخليص والجمارك','المخازن والتوزيع','التتبع والتأمين']},
 {code:'FINANCE',nameAr:'الإدارة المالية والمدفوعات',functions:['إدارة وسائل الدفع','متابعة المعاملات','التسويات والعمولات','التمويل والتحصيل']},
 {code:'PARTNERS',nameAr:'إدارة الشركاء والتكاملات',functions:['إدارة البنوك','إدارة البنك الرئيسي','إدارة شبكات الدفع','إدارة شركات الشحن والتكاملات']},
 {code:'ERP',nameAr:'إدارة موارد المؤسسات ERP',functions:['إدارة الجهات والوحدات','الموظفون والموارد البشرية','الأصول والمشتريات','التقارير التشغيلية']},
 {code:'COMMUNITY',nameAr:'إدارة المستثمرين والمانحين والخدمات المهنية',functions:['المستثمرون والمانحون والمقرضون','محصلو الديون والمحامون','وسطاء الأسواق والموردون','التبرعات والديون']},
 {code:'RISK',nameAr:'إدارة المخاطر والامتثال والأمن',functions:['مراجعة التدقيق','إدارة المستخدمين والصلاحيات','مكافحة الاحتيال والامتثال','النسخ الاحتياطي والاستعادة']}
];
const groups = {
 'إدارة المنصة':['workspace.view','workspace.manage','settings.view','settings.manage','branding.manage','sectors.view','sectors.manage','services.view','services.manage','content.manage','features.manage'],
 'العملاء والتجار':['users.view','users.create','users.update','users.suspend','users.manage','customers.view','customers.create','customers.update','customers.suspend','customers.manage','merchants.view','merchants.review','merchants.approve','merchants.reject','merchants.suspend','merchants.manage','merchant.connections.view','merchant.connections.approve','merchant.connections.manage','merchant.portals.view','merchant.portals.approve','merchant.portals.suspend','merchant.portals.manage','products.view','products.create','products.update','products.moderate','products.approve','products.reject','products.publish','products.unpublish','catalog.manage'],
 'العمليات اللوجستية':['orders.view','orders.create','orders.update','orders.assign','orders.cancel','orders.manage','shipments.view','shipments.create','shipments.update','shipments.manage','tracking.view','tracking.update','tracking.manage','customs.view','customs.create','customs.update','customs.manage','warehouse.view','warehouse.receive','warehouse.dispatch','warehouse.manage','delivery.manage','insurance.view','insurance.manage','rfq.view','rfq.create','rfq.evaluate','rfq.manage'],
 'المالية والمدفوعات':['finance.view','finance.create','finance.approve','finance.reject','finance.manage','payments.methods.view','payments.methods.create','payments.methods.update','payments.methods.disable','payments.methods.manage','payments.transactions.view','payments.transactions.create','payments.transactions.confirm','payments.transactions.manage','payments.refund','payments.settlement.view','payments.settlement.prepare','payments.settlement.approve','payments.settlement.manage','fees.manage','commissions.view','commissions.manage','debts.view','debts.create','debts.update','debts.manage','debt.collect','debt.payment.confirm','donations.view','donations.create','donations.allocate','donations.manage','funding.view','funding.create','funding.approve','funding.manage'],
 'البنوك والشركاء والتكاملات':['partners.view','partners.create','partners.update','partners.disable','partners.manage','partners.primary_bank','banks.manage','payment_networks.manage','carriers.manage','integrations.view','integrations.create','integrations.update','integrations.disable','integrations.manage','routing.view','routing.manage','routing.preview','webhooks.view','webhooks.replay','webhooks.manage'],
 'ERP والمؤسسات':['enterprise.view','enterprise.create','enterprise.update','enterprise.manage','enterprise.units.manage','enterprise.employees.view','enterprise.employees.create','enterprise.employees.update','enterprise.employees.manage','enterprise.assets.view','enterprise.assets.create','enterprise.assets.update','enterprise.assets.dispose','enterprise.assets.manage','enterprise.procurement.manage','enterprise.reports.view'],
 'المستثمرون والخدمات المهنية':['providers.view','providers.create','providers.verify','providers.suspend','providers.manage','investors.manage','donors.manage','lenders.manage','collectors.manage','lawyers.manage','china_brokers.manage','provider.engagements.view','provider.engagements.create','provider.engagements.close','provider.engagements.manage'],
 'التقارير والرقابة':['reports.view','reports.export','audit.view','audit.export','risk.view','risk.manage','compliance.view','compliance.manage','backup.view','backup.create','backup.manage','restore.manage'],
 'المستخدمون والصلاحيات':['roles.view','roles.create','roles.update','roles.delete','roles.manage','permissions.view','permissions.assign','permissions.revoke','permissions.manage','sessions.view','sessions.revoke','sessions.manage']
};
export const PERMISSIONS = Object.entries(groups).flatMap(([group,keys])=>keys.map(key=>({key,group,description:key.replaceAll('.',' / ').replaceAll('_',' ')})));
export const ROLES = [
 {key:'ADMIN',nameAr:'مدير النظام العام',description:'صلاحية شاملة غير قابلة للتفويض من خلال مصفوفة الأدوار.'},
 {key:'OPS',nameAr:'مدير العمليات',description:'إدارة العمليات والقطاعات والتجار وفق الصلاحيات الممنوحة.'},
 {key:'FINANCE',nameAr:'مدير مالي',description:'المدفوعات والتمويل والتسويات والتقارير المالية.'},
 {key:'SUPPORT',nameAr:'خدمة العملاء والدعم',description:'خدمة العملاء ومتابعة الطلبات دون صلاحيات مالية حساسة.'},
 {key:'COMPLIANCE',nameAr:'الامتثال والمخاطر',description:'التدقيق والامتثال ومراجعة السجلات.'},
 {key:'MERCHANT',nameAr:'تاجر',description:'إدارة متجره ومنتجاته بعد اعتماد حساب التاجر.'},
 {key:'CLIENT',nameAr:'عميل',description:'استخدام خدمات العميل والطلبات دون إدارة المنتجات.'}
];
export const DEFAULT_GRANTS = {
 OPS:['workspace.view','sectors.view','sectors.manage','services.view','services.manage','users.view','customers.view','merchants.view','merchants.review','merchant.connections.view','merchant.connections.approve','merchant.connections.manage','merchant.portals.view','merchant.portals.approve','merchant.portals.manage','products.view','products.moderate','products.publish','orders.view','orders.assign','orders.manage','shipments.view','shipments.manage','tracking.view','customs.view','warehouse.view','delivery.manage','insurance.manage','rfq.manage','partners.view','integrations.view','routing.view','routing.preview','enterprise.view','enterprise.manage','providers.view','providers.manage','reports.view','audit.view'],
 FINANCE:['workspace.view','finance.view','finance.manage','payments.methods.view','payments.methods.manage','payments.transactions.view','payments.transactions.manage','payments.settlement.view','payments.settlement.manage','fees.manage','commissions.view','commissions.manage','debts.view','debts.manage','donations.view','donations.manage','funding.view','funding.manage','reports.view','reports.export','partners.view'],
 SUPPORT:['customers.view','orders.view','shipments.view','tracking.view','merchants.view','products.view'],
 COMPLIANCE:['audit.view','audit.export','risk.view','risk.manage','compliance.manage','users.view','reports.view','payments.transactions.view','partners.view','integrations.view'],
 MERCHANT:['products.view','orders.view','shipments.view'],
 CLIENT:['orders.create','orders.view','shipments.view','tracking.view','products.view','payments.methods.view','donations.view','debts.view']
};
