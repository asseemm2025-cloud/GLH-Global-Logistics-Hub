import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here = path.dirname(fileURLToPath(import.meta.url));
const html = fs.readFileSync(path.join(here, '../../web/index.html'), 'utf8');

test('client navigation exposes three working hub shortcuts beside the home button', () => {
  assert.match(html, /الخدمات المالية والمجتمعية/);
  assert.match(html, /href="\/community\.html"/);
  assert.match(html, /السوق والخدمات/);
  assert.match(html, /href="\/marketplace\.html"/);
  assert.match(html, /بوابة العميل والتاجر/);
  assert.match(html, /href="\/merchant\.html"/);
  assert.match(html, /id="clientNav"[\s\S]*?الرئيسية[\s\S]*?home-shortcut shortcut-finance[\s\S]*?home-shortcut shortcut-market[\s\S]*?home-shortcut shortcut-portal/);
  assert.match(html, /@media\(max-width:760px\)[\s\S]*?overflow-x:auto/);
  assert.doesNotMatch(html, /<section class="home-hubs"/);
});
